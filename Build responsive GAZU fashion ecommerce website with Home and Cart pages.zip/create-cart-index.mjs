import { copyFileSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

const outputDirectory = resolve('dist');
const cartDirectory = resolve(outputDirectory, 'cart');

mkdirSync(cartDirectory, { recursive: true });
copyFileSync(resolve(outputDirectory, 'cart.html'), resolve(cartDirectory, 'index.html'));
