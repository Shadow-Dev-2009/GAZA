# GAZU store data required before launch

**Current state: not production-ready.** No authoritative catalog or commerce integration was available when this site was built. All product records, imagery, category/collection labels, variant values, and campaign copy are visibly identified as sample placeholders. Prices, currency, shipping, tax, discounts, and checkout remain unconfigured.

Please provide or confirm each item from the authoritative store system or store owner before launch:

| Missing input | Required owner confirmation |
| --- | --- |
| Live product catalog | Approved product names, descriptions, identifiers/SKUs, product images/usage rights, active/inactive state, inventory availability, and product-to-category/collection assignments. |
| Product variants | The actual variant labels/options for every sellable item, plus variant availability and any variant-specific pricing. Current “Option 01/02/03” labels are placeholders. |
| Actual prices | Current approved price for each sellable product/variant, including any required price precision or price-display rules. No values are present in this prototype. |
| Currency | The store's authoritative ISO 4217 currency and preferred display/locale conventions. No currency is configured. |
| Shipping rules and threshold | Regions served, delivery methods/rates, any free-shipping threshold and its currency, eligible items, and any additional shipping charges. No shipping threshold or rate is configured. |
| Tax rules | Tax regions/jurisdictions, whether displayed prices include tax, and the authoritative calculation method/provider, including rules for shipping or discounts. The prototype's tax setting is intentionally unconfigured; its simple example percentage setting must not be used as a production tax engine. |
| Promotion rules | Valid codes, start/end dates and time zones, eligible products/regions, stacking/usage restrictions, and the approved discount calculation. No promo codes are configured. |
| Returns/refunds/exchanges policy | The approved policy text, eligibility, exclusions, time window, and applicable regions. No return promise or policy is stated. |
| Relevant dates | Owner-confirmed campaign, promotion, shipping, and policy effective dates, with timezone where relevant. No dates or delivery promises are shown as factual. |
| Checkout/commerce integration | Name and configuration of the actual store platform/provider, approved checkout handoff URL/mechanism, and any required server-side integration. No real checkout is configured; do not add a handoff URL without it. |
| Security claims | Store-owner/provider-approved exact language and evidence for any payment-security, privacy, or certification claim. No such claim is made by this prototype. |
| Newsletter integration | Mailing-list provider, consent/privacy language, and approved signup behavior. The newsletter block is informational and does not collect addresses. |
| Brand/content approvals | Approval for the GAZU wordmark treatment, editorial campaign copy, category labels, photography, and image licensing. Current generated visuals and copy are sample concepts. |

The current build is a portable UI prototype only. Completing this table does not itself connect a payment provider, guarantee legal compliance, or make the site production-ready; implement and validate the appropriate integration before launch.
