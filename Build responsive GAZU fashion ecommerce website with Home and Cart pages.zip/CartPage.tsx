import { useState, type FormEvent } from 'react';
import { AssetImage } from '../components/AssetImage';
import { calculateCart, clampCartQuantity, formatCartMoney, lineKey, type CartLine } from '../lib/cart';
import { findPromoRule, products, storeConfiguration, type Product } from '../data/store';

type CartPageProps = {
  lines: CartLine[];
  lastRemoved: CartLine | null;
  onOpenProduct: (product: Product) => void;
  onQuantityChange: (key: string, quantity: number) => void;
  onVariantChange: (key: string, variant: string) => void;
  onRemove: (line: CartLine) => void;
  onUndoRemove: () => void;
};

export function CartPage({
  lines,
  lastRemoved,
  onOpenProduct,
  onQuantityChange,
  onVariantChange,
  onRemove,
  onUndoRemove,
}: CartPageProps) {
  const [promoText, setPromoText] = useState('');
  const [activePromo, setActivePromo] = useState('');
  const [promoMessage, setPromoMessage] = useState('');
  const [quantityDrafts, setQuantityDrafts] = useState<Record<string, string>>({});
  const totals = calculateCart(lines, activePromo);
  const cartCount = lines.reduce((sum, line) => sum + line.quantity, 0);

  function applyPromo(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const code = promoText.trim();
    if (!code) {
      setPromoMessage('Enter a code to check it against configured store promotions.');
      setActivePromo('');
      return;
    }
    const rule = findPromoRule(code);
    if (rule) {
      setActivePromo(rule.code);
      setPromoMessage('Code accepted using the configured store rule.');
    } else if (storeConfiguration.promoCodes.length === 0) {
      setActivePromo('');
      setPromoMessage('Promo rules are not configured; this code was not applied.');
    } else {
      setActivePromo('');
      setPromoMessage('This code does not match a configured promotion.');
    }
  }

  if (lines.length === 0) {
    return (
      <section className="cart-page page-gutter" aria-labelledby="cart-title">
        <div className="cart-heading">
          <p className="eyebrow">Your selection · sample mode</p>
          <h1 id="cart-title">The Cart<span>.</span></h1>
          <p className="cart-intro">Your bag is empty. Products added from the sample catalog will appear here.</p>
        </div>
        <div className="cart-empty">
          <span className="cart-empty__number" aria-hidden="true">00</span>
          <p>No items in your cart.</p>
          <a className="button button--dark" href="/">Return to Home</a>
        </div>
      </section>
    );
  }

  return (
    <section className="cart-page page-gutter" aria-labelledby="cart-title">
      <div className="cart-heading">
        <p className="eyebrow">Your selection · sample mode</p>
        <h1 id="cart-title">The Cart<span>.</span> <small>({cartCount})</small></h1>
        <p className="cart-intro">Sample items are not verified inventory. No payment or checkout is available.</p>
      </div>

      {lastRemoved && (
        <div className="undo-banner" role="status">
          <span>Sample item removed from your cart.</span>
          <button type="button" onClick={onUndoRemove}>Undo</button>
        </div>
      )}

      <div className="cart-layout">
        <div className="cart-lines" aria-label="Cart items">
          <div className="cart-list-heading" aria-hidden="true"><span>Item</span><span>Amount</span></div>
          {lines.map((line) => {
            const product = products.find((entry) => entry.id === line.productId);
            if (!product) return null;
            const key = lineKey(line);
            const lineAmount = product.priceMinor === null ? null : product.priceMinor * line.quantity;
            return (
              <article className="cart-line" key={key}>
                <button
                  type="button"
                  className="cart-line__image-button"
                  onClick={() => onOpenProduct(product)}
                  aria-haspopup="dialog"
                  aria-label={`Open options for ${product.name}`}
                >
                  <AssetImage src={product.image} alt={product.alt} fallbackTone={product.fallbackTone} />
                </button>
                <div className="cart-line__details">
                  <p className="eyebrow">SAMPLE · NOT VERIFIED INVENTORY</p>
                  <h2>{product.name}</h2>
                  <p className="cart-line__variant-note">Sample variant</p>
                  <label className="field-label" htmlFor={`variant-${product.id}-${line.variant.replace(/ /g, '-')}`}>Variant</label>
                  <select
                    id={`variant-${product.id}-${line.variant.replace(/ /g, '-')}`}
                    value={line.variant}
                    onChange={(event) => onVariantChange(key, event.target.value)}
                  >
                    {product.variants.map((variant) => <option value={variant} key={variant}>{variant}</option>)}
                  </select>
                  <div className="cart-line__controls">
                    <label className="field-label" htmlFor={`quantity-${product.id}-${line.variant.replace(/ /g, '-')}`}>Quantity</label>
                    <input
                      id={`quantity-${product.id}-${line.variant.replace(/ /g, '-')}`}
                      type="number"
                      min="1"
                      max="99"
                      step="1"
                      inputMode="numeric"
                      value={quantityDrafts[key] ?? String(line.quantity)}
                      onChange={(event) => {
                        const raw = event.target.value;
                        if (raw === '') {
                          setQuantityDrafts((current) => ({ ...current, [key]: '' }));
                          return;
                        }
                        const value = Number.parseInt(raw, 10);
                        if (Number.isFinite(value)) {
                          const normalized = clampCartQuantity(value);
                          setQuantityDrafts((current) => ({ ...current, [key]: String(normalized) }));
                          onQuantityChange(key, normalized);
                        }
                      }}
                      onBlur={() => {
                        const draft = quantityDrafts[key];
                        if (draft && Number.isFinite(Number.parseInt(draft, 10))) {
                          onQuantityChange(key, clampCartQuantity(Number.parseInt(draft, 10)));
                        }
                        setQuantityDrafts((current) => {
                          const next = { ...current };
                          delete next[key];
                          return next;
                        });
                      }}
                    />
                    <button className="text-button" type="button" onClick={() => onRemove(line)} aria-label={`Remove ${product.name} from cart`}>Remove</button>
                  </div>
                </div>
                <div className="cart-line__amount">{formatCartMoney(lineAmount)}</div>
              </article>
            );
          })}
          <p className="cart-sample-notice">Sample products, variants, and images are demonstration placeholders. Store data has not been connected.</p>
        </div>

        <aside className="cart-summary" aria-labelledby="summary-title">
          <p className="eyebrow">The totals</p>
          <h2 id="summary-title">Order summary</h2>
          <form className="promo-form" onSubmit={applyPromo}>
            <label className="field-label" htmlFor="promo-code">Promo code</label>
            <div className="promo-form__row">
              <input
                id="promo-code"
                type="text"
                autoComplete="off"
                value={promoText}
                onChange={(event) => setPromoText(event.target.value)}
                placeholder="Enter code"
              />
              <button type="submit" className="button button--light">Apply</button>
            </div>
            {promoMessage && <p className="promo-feedback" role="status">{promoMessage}</p>}
          </form>
          <dl className="totals-list">
            <div><dt>Subtotal</dt><dd>{formatCartMoney(totals.subtotalMinor)}</dd></div>
            {activePromo && <div><dt>Promo discount</dt><dd>{formatCartMoney(totals.discountMinor)}</dd></div>}
            <div><dt>Shipping</dt><dd>{formatCartMoney(totals.shippingMinor)}</dd></div>
            <div><dt>Tax</dt><dd>{formatCartMoney(totals.taxMinor)}</dd></div>
            <div className="totals-list__grand"><dt>Total</dt><dd>{formatCartMoney(totals.totalMinor)}</dd></div>
          </dl>
          <p className="summary-disclaimer">Currency, item pricing, shipping rules, and tax rules have not been supplied. Totals remain unavailable until verified store configuration is added.</p>
          {storeConfiguration.checkoutUrl ? (
            <a className="button button--dark checkout-link" href={storeConfiguration.checkoutUrl} rel="noreferrer">Continue to store checkout</a>
          ) : (
            <p className="checkout-unavailable">Checkout handoff unavailable — no real store checkout integration is configured.</p>
          )}
        </aside>
      </div>
    </section>
  );
}
