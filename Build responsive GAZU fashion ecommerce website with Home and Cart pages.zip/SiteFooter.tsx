export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-main">
        <div className="footer-brand">
          <a href="/" className="footer-wordmark" aria-label="GAZU Home">GAZU</a>
          <p>Clothing in a considered form.</p>
          <p className="footer-note">Sample storefront · not connected to live inventory.</p>
        </div>
        <div className="footer-column">
          <h2>Store</h2>
          <span>Shipping information — not configured</span>
          <span>Returns policy — not configured</span>
          <span>Product details — sample only</span>
        </div>
        <div className="footer-column">
          <h2>Connect</h2>
          <span>Customer care — not configured</span>
          <span>Newsletter — not connected</span>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© GAZU · Sample storefront</span>
        <span>Prices, policies, and checkout are not configured.</span>
      </div>
    </footer>
  );
}
