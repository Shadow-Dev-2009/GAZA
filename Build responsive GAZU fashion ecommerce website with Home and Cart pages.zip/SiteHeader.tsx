type SiteHeaderProps = {
  cartCount: number;
  currentPage: 'home' | 'cart';
};

export function SiteHeader({ cartCount, currentPage }: SiteHeaderProps) {
  return (
    <>
      <div className="announcement" role="note">
        <span>GAZU&nbsp; / &nbsp;SAMPLE STOREFRONT</span>
        <span>Catalog and store details are not configured</span>
      </div>
      <header className="site-header">
        <a className="wordmark" href="/" aria-label="GAZU Home">GAZU</a>
        <nav className="primary-nav" aria-label="Main navigation">
          <a href="/" aria-current={currentPage === 'home' ? 'page' : undefined}>Home</a>
          <a
            href="/cart"
            aria-current={currentPage === 'cart' ? 'page' : undefined}
            aria-label={`Cart${cartCount ? `, ${cartCount} ${cartCount === 1 ? 'item' : 'items'}` : ', empty'}`}
          >
            Cart <span className="cart-count" aria-hidden="true">{cartCount}</span>
          </a>
        </nav>
      </header>
    </>
  );
}
