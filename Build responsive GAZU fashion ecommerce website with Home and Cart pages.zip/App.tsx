import { useCallback, useEffect, useRef, useState } from 'react';
import { QuickView } from './components/QuickView';
import { SiteFooter } from './components/SiteFooter';
import { SiteHeader } from './components/SiteHeader';
import { CartPage } from './pages/CartPage';
import { HomePage } from './pages/HomePage';
import { addLine, clampCartQuantity, lineKey, persistCart, readCart, type CartLine } from './lib/cart';
import type { Product } from './data/store';

export function App() {
  const [lines, setLines] = useState<CartLine[]>(readCart);
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [lastRemoved, setLastRemoved] = useState<CartLine | null>(null);
  const [announcement, setAnnouncement] = useState('');
  const opener = useRef<HTMLElement | null>(null);
  const pathname = window.location.pathname.replace(/\/+$/, '') || '/';
  const isCartPage = pathname === '/cart' || pathname === '/cart.html';

  useEffect(() => persistCart(lines), [lines]);

  const closeQuickView = useCallback(() => setActiveProduct(null), []);
  const openQuickView = useCallback((product: Product) => {
    opener.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setActiveProduct(product);
  }, []);

  const addToCart = useCallback((product: Product, variant: string) => {
    setLines((current) => addLine(current, product.id, variant));
    setLastRemoved(null);
    setAnnouncement(`${product.name}, ${variant}, added to cart.`);
    setActiveProduct(null);
  }, []);

  const updateQuantity = useCallback((key: string, quantity: number) => {
    setLines((current) => current.map((line) => lineKey(line) === key ? { ...line, quantity: clampCartQuantity(quantity) } : line));
  }, []);

  const updateVariant = useCallback((key: string, variant: string) => {
    setLines((current) => {
      const selected = current.find((line) => lineKey(line) === key);
      if (!selected || selected.variant === variant) return current;
      const rest = current.filter((line) => lineKey(line) !== key);
      const match = rest.find((line) => line.productId === selected.productId && line.variant === variant);
      if (match) {
        return rest.map((line) => line === match ? { ...line, quantity: clampCartQuantity(line.quantity + selected.quantity) } : line);
      }
      return [...rest, { ...selected, variant }];
    });
  }, []);

  const removeLine = useCallback((line: CartLine) => {
    setLastRemoved(line);
    setLines((current) => current.filter((item) => lineKey(item) !== lineKey(line)));
    setAnnouncement(`${line.quantity} sample item removed. Undo is available on the Cart page.`);
  }, []);

  const undoRemove = useCallback(() => {
    if (!lastRemoved) return;
    setLines((current) => {
      const matching = current.find((line) => lineKey(line) === lineKey(lastRemoved));
      if (matching) {
        return current.map((line) => line === matching ? { ...line, quantity: clampCartQuantity(line.quantity + lastRemoved.quantity) } : line);
      }
      return [...current, { ...lastRemoved, quantity: clampCartQuantity(lastRemoved.quantity) }];
    });
    setAnnouncement('Removed item restored to your cart.');
    setLastRemoved(null);
  }, [lastRemoved]);

  const cartCount = lines.reduce((sum, line) => sum + line.quantity, 0);

  useEffect(() => {
    if (!activeProduct && opener.current) {
      const element = opener.current;
      opener.current = null;
      element.focus();
    }
  }, [activeProduct]);

  return (
    <div className="site-shell">
      <a className="skip-link" href="#main-content">Skip to main content</a>
      <SiteHeader cartCount={cartCount} currentPage={isCartPage ? 'cart' : 'home'} />
      <main id="main-content">
        {isCartPage ? (
          <CartPage
            lines={lines}
            lastRemoved={lastRemoved}
            onOpenProduct={openQuickView}
            onQuantityChange={updateQuantity}
            onVariantChange={updateVariant}
            onRemove={removeLine}
            onUndoRemove={undoRemove}
          />
        ) : <HomePage onOpenProduct={openQuickView} />}
      </main>
      <SiteFooter />
      <div className="sr-only" role="status" aria-live="polite" aria-atomic="true">{announcement}</div>
      {activeProduct && <QuickView product={activeProduct} onClose={closeQuickView} onAdd={addToCart} />}
    </div>
  );
}
