import { findPromoRule, products, storeConfiguration, type ShippingRule } from '../data/store';

export type CartLine = {
  productId: string;
  variant: string;
  quantity: number;
};

const CART_KEY = 'gazu-sample-cart-v1';
export const MAX_CART_QUANTITY = 99;

export function clampCartQuantity(quantity: number): number {
  if (!Number.isFinite(quantity)) return 1;
  return Math.min(MAX_CART_QUANTITY, Math.max(1, Math.trunc(quantity)));
}

export function readCart(): CartLine[] {
  try {
    const raw = window.localStorage.getItem(CART_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const validLines = parsed.filter((item): item is CartLine => {
      if (!item || typeof item !== 'object') return false;
      const line = item as Partial<CartLine>;
      return Boolean(
        products.some((product) => product.id === line.productId) &&
          typeof line.variant === 'string' &&
          typeof line.quantity === 'number' &&
          Number.isInteger(line.quantity) &&
          line.quantity > 0,
      );
    });
    return validLines.map((line) => ({ ...line, quantity: clampCartQuantity(line.quantity) }));
  } catch {
    return [];
  }
}

export function persistCart(lines: CartLine[]): void {
  try {
    window.localStorage.setItem(CART_KEY, JSON.stringify(lines));
  } catch {
    // The in-memory cart remains usable when browser storage is unavailable.
  }
}

export function lineKey(line: Pick<CartLine, 'productId' | 'variant'>): string {
  return `${line.productId}::${line.variant}`;
}

export function addLine(lines: CartLine[], productId: string, variant: string): CartLine[] {
  const existing = lines.find((line) => line.productId === productId && line.variant === variant);
  if (!existing) return [...lines, { productId, variant, quantity: 1 }];
  return lines.map((line) =>
    line === existing ? { ...line, quantity: clampCartQuantity(line.quantity + 1) } : line,
  );
}

export type CartTotals = {
  subtotalMinor: number | null;
  discountMinor: number | null;
  shippingMinor: number | null;
  taxMinor: number | null;
  totalMinor: number | null;
  appliedPromo: string | null;
};

function shippingCharge(rule: ShippingRule, subtotal: number): number | null {
  switch (rule.kind) {
    case 'free':
      return 0;
    case 'flat':
      return rule.amountMinor;
    case 'threshold':
      return subtotal >= rule.freeAboveMinor ? 0 : rule.feeMinor;
    case 'unconfigured':
      return null;
  }
}

export function calculateCart(lines: CartLine[], promoCode: string): CartTotals {
  const linePrices = lines.map((line) => {
    const product = products.find((entry) => entry.id === line.productId);
    return product?.priceMinor === null || product === undefined
      ? null
      : product.priceMinor * line.quantity;
  });
  const subtotalMinor = linePrices.some((value) => value === null)
    ? null
    : linePrices.reduce<number>((sum, value) => sum + (value ?? 0), 0);
  const promo = promoCode ? findPromoRule(promoCode) : undefined;
  const discountMinor = subtotalMinor === null
    ? null
    : promo
      ? promo.kind === 'percent'
        ? Math.min(subtotalMinor, Math.round((subtotalMinor * promo.value) / 100))
        : Math.min(subtotalMinor, promo.valueMinor)
      : 0;
  const discountedSubtotal = subtotalMinor === null || discountMinor === null
    ? null
    : Math.max(0, subtotalMinor - discountMinor);
  const shippingMinor = discountedSubtotal === null
    ? null
    : shippingCharge(storeConfiguration.shipping, discountedSubtotal);
  const taxMinor = discountedSubtotal === null || storeConfiguration.tax.kind === 'unconfigured'
    ? null
    : Math.round((discountedSubtotal * storeConfiguration.tax.basisPoints) / 10000);
  const taxAddedToTotal = storeConfiguration.tax.kind === 'rate' && storeConfiguration.tax.mode === 'exclusive';
  const totalMinor = discountedSubtotal === null || shippingMinor === null || taxMinor === null
    ? null
    : discountedSubtotal + shippingMinor + (taxAddedToTotal ? taxMinor : 0);

  return {
    subtotalMinor,
    discountMinor,
    shippingMinor,
    taxMinor,
    totalMinor,
    appliedPromo: promo ? promo.code : null,
  };
}

export function formatCartMoney(amountMinor: number | null): string {
  if (amountMinor === null || !storeConfiguration.currency) return 'Not configured';
  try {
    return new Intl.NumberFormat(undefined, {
      style: 'currency',
      currency: storeConfiguration.currency,
    }).format(amountMinor / 100);
  } catch {
    return 'Not configured';
  }
}
