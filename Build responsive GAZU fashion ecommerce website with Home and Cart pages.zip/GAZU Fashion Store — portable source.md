# GAZU Fashion Store — portable source

This is a responsive, two-page GAZU storefront prototype built with React, TypeScript, and Vite. It recreates the supplied editorial reference as real page layouts rather than image backgrounds. It is intentionally a **sample storefront**, not a production shop: no authoritative product feed, real prices, currency, shipping/tax rules, promotion rules, newsletter provider, or checkout integration was present in the project.

## Requirements and local development

- Node.js 20 or newer
- npm 10.9.9 (pinned in `package.json`)

```sh
npm ci
npm run dev
```

Vite serves the Home page at `/` and the Cart page at both `/cart` (clean URL) and `/cart.html` (legacy HTML entry). Cart contents are stored in the visitor's browser `localStorage`; no server, database, or payment processing is used.

## Build and host elsewhere

Create a static production build with:

```sh
npm ci
npm run build
```

Publish the contents of `dist/` as the site root. The build keeps `cart.html` and emits `cart/index.html`; directory-index hosts can serve `/cart` directly while `/cart.html` remains available. On Netlify, select `npm run build` as the build command and `dist` as the publish directory. On Vercel, use the Vite preset, `npm run build`, and `dist`. On Cloudflare Pages or other static hosts, use the same build command and output directory. If a target host does not resolve a directory URL to its `index.html`, add its native rewrite from `/cart` to `/cart.html`; the project itself does not assume a third-party provider.

The generated editorial photos use the project's stable `/manus-storage/...` paths when previewed on Manus. Those paths are platform-served and will not resolve automatically on unrelated hosts. The layout has a built-in, clearly marked sample-image fallback so the site still runs elsewhere. For a fully self-contained off-platform release, copy properly licensed or store-approved image files to `public/images/`, change the `image` paths in `src/data/store.ts` and the two editorial image paths in `src/pages/HomePage.tsx` to `/images/<filename>`, then rebuild. The current catalog images and fallback copy are concepts only and are not verified inventory.

## Store data and calculations

Edit `src/data/store.ts` to connect verified products, variants, prices (in minor currency units), currency, configured promotion rules, shipping rules, tax rules, and a real checkout handoff if one already exists. The default is deliberately unconfigured: prices and currency are null, shipping and tax are unknown, the promo rule list is empty, and the checkout URL is null. The Cart displays “Not configured” instead of inventing a zero-cost total. Do not add a checkout URL unless it is supplied by an actual store checkout integration. The simple configuration types are a prototype boundary, not a substitute for a region-aware tax/shipping integration.

The two purchase options in Quick View are intentionally limited: “Buy Now” is static, noninteractive text; “Add to Cart” adds the selected sample item and variant. The Cart supports variant edits, quantities, removal/undo, promo-code entry, and configured calculations. An unknown calculation remains visibly unknown. The newsletter block and editorial/category/collection calls to action are noninteractive sample content.

## Source map

- `src/data/store.ts` — sample catalog and owner-editable store configuration
- `src/lib/cart.ts` — browser cart storage and configured-total calculations
- `src/components/` — reusable imagery, navigation, footer, and quick view
- `src/pages/HomePage.tsx`, `src/pages/CartPage.tsx` — the two pages
- `src/styles.css` — responsive editorial design system and focus states
- `public/manus-routes.json` — Home and both Cart URL aliases
- `scripts/create-cart-index.mjs` — emits the clean Cart URL entry in the static build
- `STORE-LAUNCH-CHECKLIST.md` — required owner/authoritative inputs before production

## Checkout and privacy

This prototype does not accept payment, create orders, collect customer details, submit newsletter addresses, or make security/payment-completion claims. Local cart state is browser-only and can be cleared by the visitor. Connect a real commerce provider and its documented checkout handoff before enabling any production checkout path.
