import { AssetImage } from '../components/AssetImage';
import { categories, collections, formatPrice, products, storeConfiguration, type Product } from '../data/store';

type HomePageProps = { onOpenProduct: (product: Product) => void };

function SectionHeading({ kicker, title, note, id }: { kicker: string; title: string; note?: string; id?: string }) {
  return (
    <div className="section-heading">
      <div>
        <p className="eyebrow">{kicker}</p>
        <h2 id={id}>{title}</h2>
      </div>
      {note && <span className="section-note">{note}</span>}
    </div>
  );
}

export function HomePage({ onOpenProduct }: HomePageProps) {
  return (
    <div className="home-page">
      <section className="hero" aria-labelledby="hero-title">
        <AssetImage
          className="hero__image"
          src="/manus-storage/async-images/KMBM5AsD8te4AMmE1QmfsG/image-1.webp"
          alt="Sample fashion editorial featuring two models in minimal black and ivory clothing"
          fallbackTone="chalk"
        />
        <div className="hero__wash" aria-hidden="true" />
        <div className="hero__content">
          <p className="eyebrow">Independent wardrobe study · sample visual</p>
          <h1 id="hero-title">Fashion<br />that moves<br />with you.</h1>
          <span className="hero__wordmark" aria-hidden="true">GAZU</span>
          <p className="hero__footnote">Editorial imagery is a sample concept, not store inventory.</p>
        </div>
        <span className="hero__index" aria-hidden="true">01 — 03</span>
      </section>

      <section className="category-section page-gutter" aria-labelledby="category-title">
        <SectionHeading id="category-title" kicker="The wardrobe" title="A study in everyday form" note="Sample categories · not live collections" />
        <div className="category-grid">
          {categories.map((category, index) => (
            <article className="category-card" key={category.name}>
              <div className="category-card__image">
                <AssetImage src={category.image} alt={category.alt} fallbackTone={category.fallbackTone} />
                <span className="category-card__number">0{index + 1}</span>
              </div>
              <div className="category-card__copy">
                <div><h3>{category.name}</h3><p>{category.descriptor}</p></div>
                <span className="plain-cta" aria-hidden="true">Explore <span>↗</span></span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="campaign page-gutter" aria-labelledby="campaign-title">
        <div className="campaign__image-wrap">
          <AssetImage
            src="/manus-storage/async-images/KMBM5AsD8te4AMmE1QmfsG/image-2.webp"
            alt="Sample winter fashion editorial of a model in a long charcoal coat"
            fallbackTone="slate"
          />
          <span className="image-label">CAMPAIGN STUDY / SAMPLE</span>
        </div>
        <div className="campaign__copy">
          <p className="eyebrow">A seasonal study</p>
          <h2 id="campaign-title">New<br /><em>perspectives.</em></h2>
          <p>A quiet edit of shapes and layers. This campaign is visual sample content and does not represent a live season or dated offer.</p>
          <span className="plain-cta">Explore the edit <span>↗</span></span>
          <span className="campaign__stamp">STUDY<br />NO. 01</span>
        </div>
      </section>

      <section className="service-strip page-gutter" aria-label="Store information status">
        <div><span className="service-strip__index">01</span><h2>Shipping</h2><p>Store details not configured</p></div>
        <div><span className="service-strip__index">02</span><h2>Returns</h2><p>Policy not provided</p></div>
        <div><span className="service-strip__index">03</span><h2>Checkout</h2><p>No live integration connected</p></div>
      </section>

      <section className="products-section page-gutter" aria-labelledby="products-title">
        <SectionHeading id="products-title" kicker="Selection 01" title="Featured pieces" note="Sample placeholders · not for sale" />
        <div className="product-grid">
          {products.map((product, index) => (
            <article className="product-card" key={product.id}>
              <button
                type="button"
                className="product-card__image-button"
                onClick={() => onOpenProduct(product)}
                aria-haspopup="dialog"
                aria-label={`Open options for ${product.name}`}
              >
                <AssetImage src={product.image} alt={product.alt} fallbackTone={product.fallbackTone} />
                <span className="product-card__view">View options <span aria-hidden="true">↗</span></span>
                <span className="product-card__sample">SAMPLE 0{index + 1}</span>
              </button>
              <div className="product-card__meta">
                <div><h3>{product.name}</h3><p>Not verified store inventory</p></div>
                <span>{formatPrice(product.priceMinor)}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="collections-section page-gutter" aria-labelledby="collections-title">
        <SectionHeading id="collections-title" kicker="Selection 02" title="Curated collections" note="Concept placeholders" />
        <div className="collection-grid">
          {collections.map((collection, index) => (
            <article className="collection-card" key={collection.name}>
              <div className="collection-card__image">
                <AssetImage src={collection.image} alt={collection.alt} fallbackTone={collection.fallbackTone} />
                <span className="collection-card__number">0{index + 1}</span>
              </div>
              <div className="collection-card__meta">
                <div><h3>{collection.name}</h3><p>{collection.note}</p></div>
                <span className="plain-cta" aria-hidden="true">View <span>↗</span></span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="newsletter page-gutter" aria-labelledby="newsletter-title">
        <div className="newsletter__mark" aria-hidden="true">G.</div>
        <div>
          <p className="eyebrow">A note from GAZU</p>
          <h2 id="newsletter-title">Stay in the loop.</h2>
          <p>Newsletter signup is not connected in this sample storefront.</p>
        </div>
        <span className="newsletter__status">EMAIL UPDATES<br />NOT CONFIGURED</span>
      </section>
      {storeConfiguration.sampleMode && <p className="sr-only">Sample mode is active. No verified product prices, store currency, shipping rules, tax rules, or checkout integration are configured.</p>}
    </div>
  );
}
