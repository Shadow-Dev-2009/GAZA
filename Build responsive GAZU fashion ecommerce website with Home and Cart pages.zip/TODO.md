# TODO

## 1. Home and Cart pages — complete
- [x] Create exactly two pages: **Home** and **Cart**. The homepage includes navigation with functional Home and Cart links, editorial hero, category cards, seasonal campaign, service strip, featured products, curated collections, newsletter signup area, and dark footer. Keep navigation limited to Home and Cart; do not create additional page destinations. Category cards, campaign links, footer links, and other calls to action should appear as plain, noninteractive text unless specified below.
- [x] Recreate responsive layouts as real pages, not screenshot backgrounds, following the supplied visual references' editorial black-and-off-white style, bold typography, generous whitespace, large fashion photography, and dark footer. Make mobile and desktop polished. Use licensed assets or clearly marked placeholders. Keep content data-driven. Treat screenshot text as sample, not store instructions or verified information.

## 2. Product options and add-to-cart flow — complete
- [x] Every product listing and Cart product image is clickable and opens a product options panel or quick view on the current page. Show exactly two purchase options: **Buy Now** displayed as noninteractive text that does not work as a button or start checkout; **Add to Cart** is the only active purchase button. Clicking it adds the selected product and variant to the cart, updates cart count, and makes the item visible on the Cart page.
- [x] Keep every active interaction keyboard-operable and accessible with clear labels and visible focus states. Other buttons and controls remain nonfunctional unless required for Home/Cart navigation, product image and Add to Cart flow, or specified cart operations.

## 3. Cart operations — complete
- [x] The Cart page supports selecting product variants, changing quantities, removing items with an undo option, entering promo codes, and showing subtotals and totals. Cart updates are stored in browser local storage and survive page navigation/refresh.

## 4. Authoritative calculations and safe checkout — awaiting store data
- [ ] Calculate shipping and taxes and display accurate subtotal and total only after actual product prices, currency, shipping rates/thresholds, tax rules, and applicable jurisdiction data are supplied. The interface keeps unknown amounts explicitly unavailable instead of treating them as zero. Promo codes are only applied when an authoritative rule is entered. Provide a checkout handoff only if a real store checkout integration is already configured. Do not fake payment processing or imply payment completion.
- [x] Use real store data and the existing commerce integration when available. No catalog, merchant checkout, or commerce configuration was available in this project; the site visibly identifies generic listings, variants, category labels, and images as sample data/placeholders. It does not invent prices, currency, shipping thresholds, return policies, delivery promises, dates, or payment-security claims.

## 5. Portable source and pre-launch inputs
- [x] Deliver complete portable source code so the site can be hosted on other platforms. Include deployment and configuration instructions and integration notes.
- [x] List missing inputs clearly in `STORE-LAUNCH-CHECKLIST.md`, including actual prices, currency, shipping threshold, return policy, relevant dates, and security claims, along with the other missing catalog, variant, shipping/tax, promo, checkout, newsletter, and brand approvals.
- [ ] Before the site is treated as production-ready, confirm actual prices, currency, shipping threshold, return policy, relevant dates, and any security claims with the store owner or authoritative store data. Those inputs have not yet been supplied.
