import { useEffect, useRef, useState } from 'react';
import type { Product } from '../data/store';
import { formatPrice } from '../data/store';
import { AssetImage } from './AssetImage';

type QuickViewProps = {
  product: Product;
  onClose: () => void;
  onAdd: (product: Product, variant: string) => void;
};

export function QuickView({ product, onClose, onAdd }: QuickViewProps) {
  const [variant, setVariant] = useState(product.variants[0] ?? 'Sample option');
  const closeButton = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    closeButton.current?.focus();
    const handleKeys = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
      }
      if (event.key === 'Tab') {
        const controls = Array.from(
          document.querySelectorAll<HTMLElement>(
            '.quick-view [href], .quick-view button:not([disabled]), .quick-view select',
          ),
        ).filter((element) => element.offsetParent !== null);
        if (controls.length === 0) return;
        const first = controls[0];
        const last = controls[controls.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', handleKeys);
    return () => document.removeEventListener('keydown', handleKeys);
  }, [onClose]);

  return (
    <div
      className="quick-view-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section className="quick-view" role="dialog" aria-modal="true" aria-labelledby="quick-view-title">
        <button ref={closeButton} className="quick-view__close" type="button" onClick={onClose} aria-label="Close product options">
          <svg aria-hidden="true" viewBox="0 0 24 24"><path d="M5 5l14 14M19 5 5 19" /></svg>
        </button>
        <div className="quick-view__image">
          <AssetImage src={product.image} alt={product.alt} fallbackTone={product.fallbackTone} />
        </div>
        <div className="quick-view__details">
          <p className="eyebrow">SAMPLE PRODUCT · NOT VERIFIED INVENTORY</p>
          <h2 id="quick-view-title">{product.name}</h2>
          <p>{product.description}</p>
          <p className="quick-view__price">{formatPrice(product.priceMinor)}</p>
          <label className="field-label" htmlFor="product-variant">Select a sample variant</label>
          <select id="product-variant" value={variant} onChange={(event) => setVariant(event.target.value)}>
            {product.variants.map((option) => <option key={option} value={option}>{option}</option>)}
          </select>
          <p className="variant-note">Sample options only · replace with verified store variants.</p>
          <div className="purchase-options" aria-label="Purchase options">
            <span className="buy-now-text" aria-disabled="true">Buy Now</span>
            <button className="button button--dark" type="button" onClick={() => onAdd(product, variant)}>
              Add to Cart
            </button>
          </div>
          <p className="sample-caption">No live price or checkout is configured.</p>
        </div>
      </section>
    </div>
  );
}
