export type Product = {
  id: string;
  name: string;
  description: string;
  image: string;
  fallbackTone: string;
  alt: string;
  variants: string[];
  priceMinor: number | null;
};

export type PromoRule =
  | { code: string; kind: 'percent'; value: number }
  | { code: string; kind: 'fixed'; valueMinor: number };

export type ShippingRule =
  | { kind: 'unconfigured' }
  | { kind: 'free' }
  | { kind: 'flat'; amountMinor: number }
  | { kind: 'threshold'; feeMinor: number; freeAboveMinor: number };

export type TaxRule =
  | { kind: 'unconfigured' }
  | { kind: 'rate'; basisPoints: number; mode: 'exclusive' | 'inclusive' };

/** Replace this sample-only catalog and the null store settings with verified store data. */
export const storeConfiguration = {
  sampleMode: true,
  currency: null as string | null,
  checkoutUrl: null as string | null,
  shipping: { kind: 'unconfigured' } as ShippingRule,
  tax: { kind: 'unconfigured' } as TaxRule,
  promoCodes: [] as PromoRule[],
};

export const products: Product[] = [
  {
    id: 'sample-item-01',
    name: 'Sample item 01',
    description: 'Sample placeholder listing. Replace with verified product copy before launch.',
    image: '/manus-storage/async-images/KMBM5AsD8te4AMmE1QmfsG/image-3.webp',
    fallbackTone: 'cream',
    alt: 'Sample placeholder apparel image for sample item 01',
    variants: ['Option 01', 'Option 02', 'Option 03'],
    priceMinor: null,
  },
  {
    id: 'sample-item-02',
    name: 'Sample item 02',
    description: 'Sample placeholder listing. Replace with verified product copy before launch.',
    image: '/manus-storage/async-images/KMBM5AsD8te4AMmE1QmfsG/image-4.webp',
    fallbackTone: 'ink',
    alt: 'Sample placeholder apparel image for sample item 02',
    variants: ['Option 01', 'Option 02', 'Option 03'],
    priceMinor: null,
  },
  {
    id: 'sample-item-03',
    name: 'Sample item 03',
    description: 'Sample placeholder listing. Replace with verified product copy before launch.',
    image: '/manus-storage/async-images/KMBM5AsD8te4AMmE1QmfsG/image-5.webp',
    fallbackTone: 'stone',
    alt: 'Sample placeholder apparel image for sample item 03',
    variants: ['Option 01', 'Option 02', 'Option 03'],
    priceMinor: null,
  },
];

export const categories = [
  {
    name: 'Form & function',
    descriptor: 'A sample category',
    image: '/manus-storage/async-images/gW2tMX4sC1hZmqRffPgoKn/image-1.webp',
    fallbackTone: 'sand',
    alt: 'Editorial placeholder image for the sample Form and Function category',
  },
  {
    name: 'Soft structure',
    descriptor: 'A sample category',
    image: '/manus-storage/async-images/gW2tMX4sC1hZmqRffPgoKn/image-2.webp',
    fallbackTone: 'chalk',
    alt: 'Editorial placeholder image for the sample Soft Structure category',
  },
  {
    name: 'Outer layers',
    descriptor: 'A sample category',
    image: '/manus-storage/async-images/gW2tMX4sC1hZmqRffPgoKn/image-3.webp',
    fallbackTone: 'slate',
    alt: 'Editorial placeholder image for the sample Outer Layers category',
  },
];

export const collections = [
  {
    name: 'Quiet structure',
    note: 'Sample collection',
    image: '/manus-storage/async-images/gW2tMX4sC1hZmqRffPgoKn/image-4.webp',
    fallbackTone: 'stone',
    alt: 'Editorial placeholder image for the sample Quiet Structure collection',
  },
  {
    name: 'Everyday layers',
    note: 'Sample collection',
    image: '/manus-storage/async-images/gW2tMX4sC1hZmqRffPgoKn/image-5.webp',
    fallbackTone: 'ink',
    alt: 'Editorial placeholder image for the sample Everyday Layers collection',
  },
  {
    name: 'Seasonal study',
    note: 'Sample collection',
    image: '/manus-storage/async-images/KMBM5AsD8te4AMmE1QmfsG/image-2.webp',
    fallbackTone: 'moss',
    alt: 'Editorial placeholder image for the sample Seasonal Study collection',
  },
];

export function formatPrice(amountMinor: number | null): string {
  if (amountMinor === null || !storeConfiguration.currency) return 'Price not configured';
  try {
    return new Intl.NumberFormat(undefined, {
      style: 'currency',
      currency: storeConfiguration.currency,
    }).format(amountMinor / 100);
  } catch {
    return 'Price not configured';
  }
}

export function findPromoRule(code: string): PromoRule | undefined {
  return storeConfiguration.promoCodes.find(
    (rule) => rule.code.trim().toLowerCase() === code.trim().toLowerCase(),
  );
}
