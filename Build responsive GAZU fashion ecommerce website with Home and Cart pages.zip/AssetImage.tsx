import { useState } from 'react';

type AssetImageProps = {
  src: string;
  alt: string;
  className?: string;
  fallbackTone?: string;
};

export function AssetImage({ src, alt, className = '', fallbackTone = 'stone' }: AssetImageProps) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={`image-fallback image-fallback--${fallbackTone} ${className}`}
        role="img"
        aria-label={`${alt}. Sample image placeholder; replace with licensed store imagery.`}
      >
        <span className="image-fallback__silhouette" aria-hidden="true" />
        <span className="image-fallback__caption">Sample image placeholder</span>
      </div>
    );
  }

  return (
    <img
      className={className}
      src={src}
      alt={alt}
      loading="lazy"
      onError={() => setFailed(true)}
    />
  );
}
